# konikal
Website creator: konikal (flask)

1. Pip install konikal
2. py -m konikal create app
3. ???
4. Profit!

helpful links
* https://github.com/BillMills/pythonPackageLesson
* https://realpython.com/command-line-interfaces-python-argparse/
* https://stackoverflow.com/questions/17073688/how-to-use-argparse-subparsers-correctly