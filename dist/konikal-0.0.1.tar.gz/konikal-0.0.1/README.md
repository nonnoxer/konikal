# konikal
Website creator: konikal (flask)

1. Pip install konikal
2. py -m konikal create app
3. ???
4. Profit!